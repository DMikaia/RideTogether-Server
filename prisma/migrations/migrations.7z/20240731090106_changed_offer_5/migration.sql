-- AlterTable
ALTER TABLE "offers" ALTER COLUMN "taken" SET DEFAULT 0;

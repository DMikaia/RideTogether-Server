-- AlterTable
ALTER TABLE "offers" ADD COLUMN     "image" TEXT;
